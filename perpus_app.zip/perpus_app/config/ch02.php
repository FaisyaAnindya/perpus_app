<?php
    include 'layout.php'
?>

<div class="p-4 sm:ml-64">
    <div class="p-4 mt-14">
        <h1>Percobaan kedua.</h1>
    </div>
</div>

</body>
</html>