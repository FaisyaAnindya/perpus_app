<?php

include 'Database.php';

$database = new Database();
$database->getConnection();

?>